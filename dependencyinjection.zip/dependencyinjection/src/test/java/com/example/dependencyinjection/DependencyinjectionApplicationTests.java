package com.example.dependencyinjection;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DependencyinjectionApplicationTests {

	@Test
	void contextLoads() {
	}

}
