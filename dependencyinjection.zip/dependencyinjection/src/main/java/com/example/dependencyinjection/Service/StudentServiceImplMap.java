package com.example.dependencyinjection.Service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;

import com.example.dependencyinjection.Model.Student;

@Service
public class StudentServiceImplMap implements StudentService {
    private final Map<String, Student> studentsMap;

    public StudentServiceImplMap() {
        this.studentsMap = new HashMap<>();
        initializeTestData(); // Add some initial test students in this method.
    }

    @Override
    public void add(Student student) {
        studentsMap.put(student.getIdStudent(), student);
    }

    @Override
    public void delete(Student student) {
        studentsMap.remove(student.getIdStudent());
    }

    @Override
    public List<Student> all() {
        return new ArrayList<>(studentsMap.values());
    }

    @Override
    public Student findById(String id) {
        return studentsMap.get(id);
    }

    // Method to add some initial test students
    private void initializeTestData() {
        Student student1 = new Student("1", 0, "Mary", "Doe", 1);
        //Student student2 = new Student("2", 0, "Kelvin", "Smith", 2);
        studentsMap.put(student1.getIdStudent(), student1);
        //studentsMap.put(student2.getIdStudent(), student2);
        // Add more test students as needed
    }
}
