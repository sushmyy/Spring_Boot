package com.example.dependencyinjection.Model;

import org.aspectj.lang.annotation.Before;
import org.junit.Test;
import static org.junit.Assert.*;
import com.example.dependencyinjection.Service.StudentServiceImpl;

public class DependencyinjectionApplicationTest {

	private StudentServiceImpl studentService;

    @Before(value = "")
    public void setUp() {
        studentService = new StudentServiceImpl();
    }

    @Test
    public void testAddStudent() {
        Student student = new Student("3", 0, "Alice", "Johnson", 3);
        studentService.add(student);
        assertTrue(studentService.all().contains(student));
    }

    @Test
    public void testDeleteStudent() {
        Student student = new Student("4", 0, "Bob", "Smith", 4);
        studentService.add(student);
        studentService.delete(student);
        assertFalse(studentService.all().contains(student));
    }

    @Test
    public void testFindStudentById() {
        Student student = new Student("5", 0, "Charlie", "Wilson", 5);
        studentService.add(student);
        Student foundStudent = studentService.findById("5");
        assertEquals(student, foundStudent);
    }
}
