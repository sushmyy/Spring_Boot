package com.example.dependencyinjection.Service;

import java.util.List;

import com.example.dependencyinjection.Model.Student;

public interface StudentService {
	void add( Student student );

    void delete( Student student );

    List<Student> all();

    Student findById( String id );

}
