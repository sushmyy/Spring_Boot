package data;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JpaMysqlSampleApplicaionApplication {

	public static void main(String[] args) {
		SpringApplication.run(JpaMysqlSampleApplicaionApplication.class, args);
	}

}
